const centimerterT: number = 10000;
const convertT: number = centimerterT / 1000;
console.log(convertT);
