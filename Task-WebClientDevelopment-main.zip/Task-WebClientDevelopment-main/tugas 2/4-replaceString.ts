const wordT: string = "hello word";
const inputT: string = "ll";

const removeT: string = wordT.replace(inputT, "");

console.log(removeT);
