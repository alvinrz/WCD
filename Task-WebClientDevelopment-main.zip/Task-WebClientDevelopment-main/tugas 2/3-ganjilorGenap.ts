const angkaT: number = 12312310;

if (angkaT % 2 !== 0) {
  console.log(angkaT);
  console.log(false);
} else if (angkaT % 2 === 0) {
  console.log(angkaT % 2);
  console.log(true);
}
