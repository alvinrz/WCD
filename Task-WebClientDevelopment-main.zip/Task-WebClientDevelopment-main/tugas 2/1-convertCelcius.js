const fahrenheit = 10
const rumus = (fahrenheit - 32) / 1.8

console.log(rumus)