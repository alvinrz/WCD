const centimerter = 10000;
const convert = centimerter / 1000;
console.log(convert);
