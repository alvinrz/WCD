const angka = "12312310"

if(angka % 2 !== 0){
    console.log(angka)
    console.log(false)
} else if(angka % 2 === 0) {
    console.log(angka % 2)
    console.log(true)
}