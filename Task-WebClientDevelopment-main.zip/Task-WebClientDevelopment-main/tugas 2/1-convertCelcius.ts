const fahrenheitT: number = 10;
const rumusT: number = (fahrenheitT - 32) / 1.8;

console.log(rumusT);
