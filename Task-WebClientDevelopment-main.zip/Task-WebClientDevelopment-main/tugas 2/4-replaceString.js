const word = "hello word";
const input = "ll";

const remove = word.replace(input, "");

console.log(remove);
