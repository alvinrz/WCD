export const persegiPanjang = (lengthInput, heightInput) => {
  let length = lengthInput || 5;
  let height = heightInput || 3;

  let totalArea = length * height; // hasil : 15

  return totalArea;
};
