# Task Web Client Dvelopment

## Task 1

Tugas pertama untuk pelajaran "Web Client Development"

1. kode untuk mencari luas persegi panjang ->
   Dibuat dengan menerapkan rumus untuk mencari luas persegi panjang yang diterapkan pada bahasa pemrograman.
2. kode untuk mencari diameter, keliling, dan luas lingkaran ->
   Dibuat dengan menerapkan rumus diameter, keliling, dan luas dari lingkaran yang diterapkan pada bahasa pemrograman.
3. kode untuk mencari sudut segitiga jika diketahui dua sudutnya ->
   Dibuat dengan menerapkan rumus untuk mencari sudut persegi panjang yang diterapkan pada bahasa pemrograman.
4. kode untuk mendapatkan selisih tanggal dalam hari ->
   Dibuat dengan memasukan tanggal yang dikonversikan menjadi unix, kemudian dikurang antara tanggal akhir dan tanggal awal, kemudian di konversi kembali dari unix menjadi angka.
5. kode untuk mencetak inisial nama Anda dalam huruf kapital ->
   Dibuat dengan memasukkan nama kemudian di dipisahkan menjadi sebuah array, kemudian di looping. dalam looping itu dipisahkan menjadi per-character kemudian diambil urutan ke-0nya terakhir urutan terkahir di masukan ke sebuah array. Untuk menampilkannya array tersebut dijalankan fungsi join.

## Task 2

1. Konversi ke Celcius
2. Konversi ke Kilometer
3. Tentukan Bilangan Ganjil atau Genap
4. Mengganti String
5. String Palindrom

## Task 3

Menyempurnakan tampilan HTML dengan CSS yang sudah diberikan

## Task 4

Membuat code dengan ReactJS dan CSS framework dengan menyesuakan tampilan dengan file figma yang diberikan oleh dosen

## Task 5

## Task 6
