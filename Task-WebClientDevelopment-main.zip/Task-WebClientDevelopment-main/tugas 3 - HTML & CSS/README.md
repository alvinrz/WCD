This is repository for Exercise 3 Web Client Development(WCD) 

```
function test()=> {
    console.log("This app is running well");
}
```